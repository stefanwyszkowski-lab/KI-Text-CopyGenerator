const { GoogleGenAI, Type } = require("@google/genai");

const TEXT_LENGTHS = {
  'Kurz & Knackig': 'Sehr kurzer Text, ideal für Headlines, Social Media Ads oder Tweets.',
  'Standard': 'Ein ausgewogener Text, passend für die meisten Social Media Posts oder E-Mail Teaser.',
  'Ausführlich': 'Ein längerer, detaillierterer Text, geeignet für Blog-Einleitungen oder Landing-Page-Sektionen.'
};

exports.handler = async function (event, context) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const { productInfo, platform, selectedMethods, textLength } = JSON.parse(event.body);
    const apiKey = process.env.API_KEY;

    if (!apiKey) {
      throw new Error("API_KEY ist nicht konfiguriert.");
    }

    if (!productInfo) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Produktinformation fehlt.' }) };
    }
    
    const ai = new GoogleGenAI({ apiKey });

    let psychologyPromptPart = `Jede Variante soll einen anderen verkaufspsychologischen Schwerpunkt haben. Wähle dabei aus einem breiten Spektrum von Methoden wie Dringlichkeit, Social Proof, Autorität, Verknappung, Sympathie, Gegenseitigkeit, Commitment, Verlustangst, Neugierde und Exklusivität.`;
    if (selectedMethods && selectedMethods.length > 0) {
      psychologyPromptPart = `Fokussiere dich auf die folgenden psychologischen Methoden: ${selectedMethods.join(', ')}. Erstelle für jede ausgewählte Methode eine eigene Text-Variante.`;
    }

    const numberOfVariants = (selectedMethods && selectedMethods.length > 0) ? selectedMethods.length : '3-4';
    
    const prompt = `Erstelle ${numberOfVariants} Werbetext-Varianten für die Plattform "${platform}" basierend auf dieser Beschreibung: "${productInfo}".
    ${psychologyPromptPart}
    Die gewünschte Textlänge ist "${textLength}". Interpretiere diese Längenvorgabe im Kontext der Plattform "${platform}": ${TEXT_LENGTHS[textLength]}.
    Beachte die typischen Zeichenbegrenzungen, den Ton und die Richtlinien der Plattform.
    Gib für jede Variante einen klaren Titel für den psychologischen Ansatz an.`;
    
    const responseSchema = {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          angle: { type: Type.STRING, description: "Der psychologische Schwerpunkt der Variante." },
          headline: { type: Type.STRING, description: "Ein kurzer, aufmerksamkeitsstarker Titel." },
          body: { type: Type.STRING, description: "Der Haupttext der Werbebotschaft." },
          cta: { type: Type.STRING, description: "Ein klarer Call-to-Action." }
        },
        required: ["angle", "headline", "body", "cta"]
      }
    };

    const systemInstruction = "Du bist ein Weltklasse-Experte für Werbetexte und Verkaufspsychologie. Deine Aufgabe ist es, hochkonvertierende und kontextuell passende Werbetexte zu erstellen. Du mischst und wendest psychologische Effekte meisterhaft an. Die Texte müssen perfekt auf die ausgewählte Plattform und die gewünschte Länge zugeschnitten sein.";

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        systemInstruction: systemInstruction,
      },
    });

    const parsedResult = JSON.parse(response.text);
    
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*", // Für lokale Entwicklung
      },
      body: JSON.stringify(parsedResult),
    };

  } catch (e) {
    console.error(e);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Die KI konnte keine passende Antwort generieren. Fehler: ' + e.message }),
    };
  }
};